# America Meme Party - $AMP

Solana-based token that prevents selling by anyone except the owner.

## Build & Deploy

```bash
anchor build
anchor deploy
```